<?php
	date_default_timezone_set('Asia/Jakarta');
	error_reporting(0);

	// status
	$maintenance = 0; //Ganti jadi 1 jika sedang MT
	if($maintenance == 1) {
		header("location: /offline"); //Ganti dengan landing page maintenance Anda
	}

	// database
	$config['db'] = array(
		'host' => 'localhost',
		'name' => 'FaizKuyz', //Ganti dengan nama database anda
		'username' => 'Faiz', //Ganti dengan username database anda
		'password' => 'Faiz1123' //Ganti dengan password database anda
	);

	$conn = mysqli_connect($config['db']['host'], $config['db']['username'], $config['db']['password'], $config['db']['name']);
	if(!$conn) {
		die("Koneksi Gagal : ".mysqli_connect_error());
	}

	// Konfigurasi url domain
	$config['web'] = array(
		'url' => 'https://store.aistore.my.id/', //diakhiri garis miring. ex: https://ariepulsa.id/
		'url_canonical' => 'https://shop.aistore.my.id' //tanpa garis miring. ex: https://ariepulsa.id
	);

	// date & time
	$date = date("Y-m-d");
	$time = date("H:i:s");

	// API google captcha v2 Checkbox: https://www.google.com/recaptcha/admin/create
	$config['captcha'] = array(
		'sitekey' => '6LeiwzMmAAAAALZ5SMvhmv_4iXaOGHuZRwCXeuT0',
		'secretkey' => '6LeiwzMmAAAAAHX9XV_xvlH0QCLo79EPu9uzHwvp'
	);

	// Email SMTP, Keamanan SSL, PORT 465
	// EMAIL MAILER INI DIREKOMENDASIKAN MENGGUNAKAN EMAIL SMTP HOSTING
	// INFORMASI PORT DAN HOST DIDAPAT SETELAH MEMBUAT EMAIL DI CPANEL
	$config['email'] = array(
		'enkripsi' => 'ssl', //ssl atau tls, direkomendasikan ssl
		'mailhost' => 'cloud.aistore.my.id', //host mail, ex: mail.kincaiseluler.my.id
		'mailport' => '465', //port email, ex: 465
		'mailusername' => 'help.aistore@gmail.com', //email, ex: support@kincaiseluler.my.id
		'mailpassword' => 'Faiz1123' //password email
	);

	// versi
	$versi = '1';

	require("lib/function.php");

?>