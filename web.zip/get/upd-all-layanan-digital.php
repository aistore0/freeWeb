<!--Viewport -->
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<h3>
	<div style="text-align: center;">
		<a href="../admin-dashboard/action-provider"><b>Kembali</b></a><br/>
	</div>
</h3>

<?php
session_start();
require_once ("../config.php");
require_once ("../lib/session_login_admin.php");

    $cek_harga_website = $conn->query("SELECT * FROM setting_profit WHERE kategori = 'WEBSITE' AND tipe = 'Digital'");
    $data_harga_website = mysqli_fetch_assoc($cek_harga_website);

    $cek_harga_api = $conn->query("SELECT * FROM setting_profit WHERE kategori = 'API' AND tipe = 'Digital'");
    $data_harga_api = mysqli_fetch_assoc($cek_harga_api);
    
    $harga_website_profit = $data_harga_website['harga'];
    $harga_api_profit = $data_harga_api['harga'];

$cekarie = $conn->query("SELECT * FROM provider WHERE code = 'ARIETOPUP'");
$dataarie = mysqli_fetch_assoc($cekarie);
$action = 'layanan';

            $postdata = "api_key=".$dataarie['api_key']."&action=".$action."";
            $url = 'https://ariepulsa.id/api/produk-digital';
                
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_TIMEOUT, 0);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); // tambahan curl ipv4
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, POST);
            curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	    	$response = curl_exec($curl);
            curl_close($curl);
			/*
			echo $response;
			*/
            $json_result = json_decode($response, true);

$no = 1;
$indeks = 0; 
while($indeks < count($json_result['data'])){ 
	$id = $json_result['data'][$indeks]['sid'];
	$oprator = $json_result['data'][$indeks]['operator'];
	$name = $json_result['data'][$indeks]['layanan'];
	$price = $json_result['data'][$indeks]['harga'];
	$tipe = $json_result['data'][$indeks]['tipe'];
	$catatan = $json_result['data'][$indeks]['catatan'];
	$status = $json_result['data'][$indeks]['status'];
	$provider = "ARIETOPUP";
	$rate_asli = $price * $harga_website_profit;    //Ganti Tanda + Menjadi * Jika Ingin Merubah Profit Jadi %
	$harga_api = $price * $harga_api_profit;        //Ganti Tanda + Menjadi * Jika Ingin Merubah Profit Jadi %
	$status_asli = strtr($status, array(
	));
	$indeks++;

	$check_layanan_digital = mysqli_query($conn, "SELECT * FROM layanan_digital WHERE provider_id = '$id' AND provider = '$provider'");
	$data_layanan_digital = mysqli_fetch_assoc($check_layanan_digital);
	if(mysqli_num_rows($check_layanan_digital) > 0) {
		$update = mysqli_query($conn, "UPDATE layanan_digital SET harga = '$rate_asli', harga_api = '$harga_api', catatan = '$catatan', profit = '$profit', status = '$status_asli' WHERE provider_id = '$id' AND provider = '$provider'");
		echo ($update == TRUE) ? '<b>Produk & Harga Berhasil Diupdate</b> <br/>
		Provider ID: '.$id.' <br/>
		Operator: '.$oprator.' <br/>
		Nama: '.$name.'.<br/>
		Status Provider: '.$status.' <br/>
		Harga Provider: '.$price.' <br/>
		Tipe: '.$tipe.'.<br/>
		Catatan: '.$catatan.' <br/>
		Provider: '.$provider.' <br/>
		Harga Web: '.$rate_asli.' <br/>
		Harga Api: '.$harga_api.' <br/>
		Status Web: '.$status_asli.' <br/><br/>
		' : '<b>Produk & Harga Gagal Diupdate</b>: '.mysqli_error($conn).'<br/>';
	} else {
		$sid = $no++;
		$insert = mysqli_query($conn,"INSERT INTO layanan_digital(service_id, provider_id, operator, layanan, harga, harga_api, profit, status, provider, tipe, catatan) VALUES ('$id','$id','$oprator','$name','$rate_asli','$harga_api','$profit','$status_asli','$provider','$tipe','$catatan')");
		if($insert == TRUE){
			echo"<b>Produk Berhasil Disimpan</b> <br/>
			Provider ID: $id <br/>
			Operator: $oprator <br/>
			Nama: $name <br/>
			Status Provider: $status <br/>
			Harga Provider: $price <br/>
			Tipe: $tipe <br/>
			Catatan: $catatan <br/>
			Provider: $provider <br/>
			Harga Web: $rate_asli <br/>
			Harga Api: $harga_api <br/>
			Status Web: $status_asli <br/><br/>";
		}else{
			echo "<b>Produk Gagal Disimpan</b> <br/>";
		}
	}
}

?>