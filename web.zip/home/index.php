<?php
	session_start();
	require '../config.php';
	require '../lib/database.php';

	if (isset($_SESSION['user'])) {
		header("Location: ".$config['web']['url']);
	} else {

	?>

	<!DOCTYPE html>
	<html lang="id-ID" xml:lang="id-ID">

	    <head>

            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo $data['title']; ?></title>

            <?php
            include_once '../lib/SEOSecretIDN-meta-all.php';
            include_once '../lib/SEOSecretIDN-meta-homepageonly.php';
            ?>

			<!--App css-->
			<link href="/assets/css/scroll.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/themecolor.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>  
			<link href="css/bootstrap.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css" async/>
			<link href="css/swiper.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/animate.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/lity.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/style.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/font-family.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
			<link href="css/font-awesome.css?v<?php echo $versi; ?>" rel="stylesheet" type="text/css"/>
		</head>

		<body data-spy="scroll" data-target="#bs-example-navbar-collapse-1" data-offset="5" class="scrollspy-example without_bg_images">

			<!--navbar-->
			<nav class="navbar navbar-default navbar-fixed-top appsLand-navbar navBar__style-2">
				<div class="container">
					<!--Brand and toggle get grouped for better mobile display-->
					<div class="navbar-header">
						<span class="menu-toggle">
							<i class="chart"></i>
							<i class="chart"></i>
							<i class="chart"></i>
						</span>
						<a href="/" title="<?php echo $data['title'];?>" alt="<?php echo $data['title'];?>" class="navbar-brand">
							<img alt="<?php echo $data['short_title']; ?>" src="/assets/images/kincaimedia/webkmpanelwhite.png?v<?php echo $versi; ?>" width="auto">
						</a>
					</div>
					<!--Collect the nav links, forms, and other content for toggling-->
					<div class="app-links" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right appsLand-links">
							<li class="visible-xs-block text-center mobile-size-logo">
								<a href="#">
									<img alt="<?php echo $data['short_title']; ?>" src="/assets/images/kincaimedia/webkmpanelblack.png?v<?php echo $versi; ?>" width="200px">
								</a>
							</li>
							<li><a href="#home"><i class="fa fa-home"></i> Home</a></li>
							<li><a href="#panel"><i class="fa fa-check-circle"></i> Panel</a></li>
							<li><a href="#aplikasi"><i class="fa fa-download"></i> Aplikasi</a></li>
							<li><a href="#fitur"><i class="fa fa-star"></i> Fitur</a></li>
							<li><a href="/halaman/produk-dan-layanan" target="_blank"><i class="fa fa-shopping-cart"></i> Layanan</a></li>
							<li><a href="#faqs"><i class="fa fa-question-circle"></i> FAQs</a></li>
							<li><a href="#kontak"><i class="fa fa-comments"></i> Kontak</a></li>
						</ul>
					</div><!--/.navbar-collapse-->
				</div><!--/.container-fluid-->
			</nav>

			<!--Header-->
			<header class="active-navbar appsLand-header cloud-bg" id="home">
				<div class="app-overlay">
					<div class="header-content">
						<div class="container">
							<div class="row">
								<div class="col-lg-6 col-md-6">
									<div class="site-intro-content">
										<h1 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s" style="font-size: 24px;text-transform: uppercase;"><i class="fa fa-check-circle"></i> <?php echo $data['short_title'];?></h1><p/>
										<p class="lead wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<i class="fa fa-check" style="color:#f5f5f5"></i> Tersedia Berbagai Produk Digital Dengan Sistem PPOB.
										</p>
										<p class="lead wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<i class="fa fa-check" style="color:#f5f5f5"></i> Layanan Sosial Media Marketing (SMM) All-In-One.
										</p>
										<p class="lead wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<i class="fa fa-check" style="color:#f5f5f5"></i> Layanan Jasa Exchanger & Perbankan Terlengkap.
										</p>
										<p class="lead wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<i class="fa fa-check" style="color:#f5f5f5"></i> Produk Digital dan Voucher Games Murah.
										</p>
										<p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<i class="fa fa-list-ul" style="color:#f5f5f5"></i> Lihat <a href="/halaman/produk-dan-layanan" target="_blank" title="Produk dan Layanan <?php echo $data['short_title']; ?>" alt="Produk dan Layanan <?php echo $data['short_title']; ?>"><u style="color: #ffffff"><?php echo $total_layanan; ?>+ Produk & Jasa</u></a>.
										</p>
										<ul class="list-inline list-unstyled header-links">
											<li class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
												<a href="/auth/login" target="_blank" title="<?php echo $data['short_title'];?>" alt="<?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient btn-inverse scrollLink">
													<span><i class="fa fa-home"></i> Login</span>
												</a>
											</li>
											<li class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
												<a href="/auth/register" target="_blank" title="<?php echo $data['short_title'];?>" alt="<?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient btn-inverse scrollLink">
													<span><i class="fa fa-home"></i> Register</span>
												</a>
											</li>
										</ul>
										<br/><i class="fa fa-check-circle"></i> Powered by <?php echo $data['short_title']; ?>
									</div>
								</div>
								<div class="col-lg-4 col-md-6 hidden-xs col-lg-offset-1 hidden-sm">
									<div class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s">
										<img src="/assets/images/halaman/panel.png" title="Website <?php echo $data['short_title'];?>" alt="Website <?php echo $data['title'];?>" class="img-responsive">
									</div>
									<ul class="list-inline list-unstyled header-links" style="text-align:center; margin-top:10px; margin-left:0px;">
										<li class="wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">
											<a href="/halaman/produk-dan-layanan" title="Toko Online <?php echo $data['short_title'];?>" alt="Toko Online <?php echo $data['title'];?>"  class="appsLand-btn appsLand-btn-gradient scrollLink">
												<span><i class="fa fa-shopping-cart"></i> Produk & Layanan</span>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>

			<!--Main-->
			<main class="entry-main">

				<!--About-->
				<section class="about" id="panel">
					<div class="container">
						<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
							<h2>
								<i class="fa fa-check-circle"></i> <b><?php echo $data['title']; ?></b>
							</h2>
							<span><span></span></span>
						</div>
						<div class="section-content row">
							<div class="col-sm-6 align-left animated" data-duration="500" data-animation="fadeInLeft">
								<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
									<h3>Mengapa Memilih Kami?</h3>
									<span><span></span></span></br>
									Kami menyediakan layanan otomatisasi berteknologi AI, berkualitas, cepat & aman. Dengan mendaftar, Anda bisa menjadi Member, Agen atau Reseller layanan jasa otomatisasi Sosial Media, optimasi Toko Online, jasa Pembayaran Online dan penyedia <a title="Produk Digital <?php echo $data['short_title']; ?>" alt="Produk Digital <?php echo $data['short_title']; ?>" target="_blank" href="/halaman/produk-dan-layanan"><b>Produk Digital</b></a>.</br></br>
									<h3>Optimasi Sosial Media & Toko Online</h3>
									<span><span></span></span></br> 
									Tersedia layanan <a title="Server Panel SMM Termurah Indonesia" alt="Panel Social Media Marketing Indonesia" target="_blank" href="/halaman/produk-dan-layanan#SosialMedia"><b>Sosial Media Marketing</b></a> All-In-One untuk optimasi Youtube, Facebook, Instagram, Twitter, Pinterest, Tiktok dan WhatsApp. Juga terdapat layanan toko online untuk Shopee, Tokopedia dan Bukalapak.</br></br>
									<h3>Konten Panduan <?php echo $data['short_title']; ?></h3>
									<span><span></span></span></br>
									Kami menyediakan blog panduan menggunakan fitur dan layanan, diantaranya cara mengoptimalkan sosial media, subscribe youtube, trafik website, hingga panduan transaksi jasa dan layanan di <?php echo $data['short_title']; ?> yang bisa Anda pelajari.</br>
								</div>
							</div>

							<div class="col-sm-6 pull-right animated" data-duration="500" data-animation="fadeInRight">
								<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
									<h3>Produk Digital Terkoneksi PPOB</h3>
									<span><span></span></span></br>
									Tersedia berbagai Produk Digital dengan sistem PPOB untuk transaksi E-Money (Gojek, Grab, Dana, Ovo & Steam Wallet), <a title="Situs Voucher Game Murah" alt="Situs Voucher Game Murah" target="_blank" href="/halaman/produk-dan-layanan#TopUpGames"><b>Voucher All Games</b></a>, Token PLN, <a title="Server Pulsa H2H Termurah" alt="Server Pulsa Reguler dan Transfer H2H Termurah" target="_blank" href="/halaman/produk-dan-layanan#PulsaReguler"><b>Pulsa & Paket Internet All Operator</b></a> Prabayar & Pascabayar, Paket Telepon & SMS, hingga <a title="Situs H2H Produk Operator Global" alt="Situs Server H2H Produk Operator Global" target="_blank" href="/halaman/produk-dan-layanan#TopUpGames"><b>Produk Operator Global</b></a>.<br/></br>
									<h3>Layanan Jasa Exchanger & Perbankan</h3>
									<span><span></span></span></br>
									Layanan exchange tersedia untuk pertukaran (jual/beli) dollar, cryptocurrency, dan voucher indodax. Sedangkan pada jasa perbankan hanya E-Money Changer dan BRI Brizzi. Ini tersedia untuk semua Member, Agen, atau Reseller.</br></br>
									<h3>Portal Edukasi Mediabisnis.co.id</h3>
									<span><span></span></span></br>
									Kami juga berfokus mengembangan situs portal bisnis dan investasi. Dapatkan panduan Internet Marketing, Digital Marketing, Bisnis Affiliate, Cryptocurrency, Forex dan panduan Saham di <a title="Portal Edukasi Bisnis dan Investasi" alt="Portal Edukasi Bisnis dan Investasi" href="https://blog.kincaimedia.net" target="_blank" rel="dofollow"><b>Portal Edukasi Bisnis & Investasi</b>.</a></br>
								</div>
							</div>
						</div>
					</div>
				</section>

				<!--Aplikasi-->
				<section class="download section-bg-img" id="aplikasi">
					<div class="app-overlay">
						<div class="container">
							<div class="section-title style-gradient white-color wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s" style="visibility: visible; animation-duration: 1s; animation-delay: 0s; animation-name: fadeInUp;">
								<h2><i class="fa fa-android" style="color:#a4c639"></i> Android App</h2>
								<span><span></span></span>
								<br/>Akses <?php echo $total_layanan; ?>+ Produk & Layanan dalam 1 Aplikasi
							</div>
							<div class="download-buttons">
								<div class="row">
									<div class="col-sm-4"></div>
									<div class="col-sm-4">
										<div class="wow fadeInUp second-download-btn" data-wow-duration="1s" data-wow-delay="0s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.5s; animation-name: fadeInUp;">
											<a href="/KSStore.apk"  title="Aplikasi <?php echo $data['short_title'];?>" alt="Aplikasi <?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient"><span><i class="fa fa-download" style="color:#a4c639"></i> Download</span></a>
										</div>
									</div>
									<div class="col-sm-4"></div>
								</div>
							</div>
							<center>
								<a href="/halaman/produk-dan-layanan"> <img src="/assets/images/halaman/platform-aplikasi.png" class="img-responsive" title="<?php echo $data['short_title'];?>" alt="<?php echo $data['short_title'];?>">
								</a>
							</center>
						</div>
					</div>
				</section>

				<!--Feature-->
				<section class="mini-feature__style-2" id="fitur">
					<div class="container">
						<div class="row">
							<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
								<h2><b><i class="fa fa-star"></i> Fitur Unggulan</b></h2><br>
								<span><span></span></span>
								<div class="row">
									<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="Keamanan Transaksi <?php echo $data['short_title']; ?>" src="images/flat-icons/security.png">
												<img alt="Keamanan Transaksi <?php echo $data['short_title']; ?>" src="images/flat-icons/security.png">
											</div>
											<div class="data-box">
												<h3>Keamanan Transaksi</h3>
												<span>
													Perlindungan keamanan adalah prioritas, kami menjamin privasi data dan transaksi divalidasi & disetujui pengguna sendiri.
												</span>
											</div>
										</div>
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="Artificial Intelligence <?php echo $data['short_title']; ?>" src="images/flat-icons/bot.png">
												<img alt="Artificial Intelligence <?php echo $data['short_title']; ?>" src="images/flat-icons/bot.png">
											</div>
											<div class="data-box">
												<h3>Robot <?php echo $data['short_title']; ?></h3>
												<span>
													Fitur otomatisasi dengan AI diterapkan untuk mempopulerkan bisnis Anda di Sosial Media dan Toko Online di Marketplace.
												</span>
											</div>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="Proses Otomatis <?php echo $data['short_title']; ?>" src="images/flat-icons/rocket.png">
												<img alt="Proses Otomatis <?php echo $data['short_title']; ?>" src="images/flat-icons/rocket.png">
											</div>
											<div class="data-box">
												<h3>Sistem PPOB</h3>
												<span>
													Setiap pesanan di proses secara Otomatis dan Instan dengan PPOB, langsung pada Server utama kami tanpa penundaan.
												</span>
											</div>
										</div>
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="Integritas API <?php echo $data['short_title']; ?>" src="images/flat-icons/code.png">
												<img alt="Integritas API <?php echo $data['short_title']; ?>" src="images/flat-icons/code.png">
											</div>
											<div class="data-box">
												<h3>Terintegrasi API & H2H</h3>
												<span>
													Mendukung transaksi melalui Application Programming Interface (API). Sangat cocok untuk sistem Host to Host (H2H).
												</span>
											</div>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="App Android <?php echo $data['short_title']; ?>" src="images/flat-icons/device.png">
												<img alt="App Android <?php echo $data['short_title']; ?>" src="images/flat-icons/device.png">
											</div>
											<div class="data-box">
												<h3>Mudah Digunakan</h3>
												<span>
													Transaksi dapat diakses cepat & responsive semua perangkat, tersedia <a href="#unduh">App Mobile</a> Android yang mudah digunakan.
												</span>
											</div>
										</div>
									</div>
									<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
										<div class="mini-feature-box">
											<div class="icon-box">
												<img alt="Deposit <?php echo $data['short_title']; ?>" src="images/flat-icons/money.png">
												<img alt="Deposit smm panel" src="images/flat-icons/money.png">
											</div>
											<div class="data-box">
												<h3>Metode Pembayaran</h3>
												<span>
													Kami mendukung berbagai metode pembayaran, mulai dari pulsa, paypal, e-money, bank, e-payment dan cryptocurrency.
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<!--Testimonials-->
				<section class="testimonials section-bg-img">
					<div class="app-overlay">
						<div class="container">
							<div class="section-title style-gradient white-color wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
								<h2>
									Apa Tanggapan Mereka<i class="fa fa-question"></i> 
								</h2>
								<span><span></span></span>
							</div>
							<div class="testimonials-template">
								<div class="row">
									<div class="col-lg-10 col-lg-offset-1">
										<div class="testimonials-slider-container wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
											<div class="swiper-wrapper">
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/kikilesvina.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Kiki Lesvina</span>
																<p class="client-career">Reseller</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	Selain murah dan prosesnya cepat, fitur webnya juga lengkap. Semoga kedepannya ada aplikasi androidnya biar lebih mudah aksesnya di mobile
																</p>
															</div>
														</div>
													</div>
												</div>
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/muhammadraihan.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Muhammad Raihan</span>
																<p class="client-career">Reseller</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	Allhamdulillah berkat panel sosmed ini pekerjaan saya sebagai seller produk virtual jadi lebih mudah ningkatin popularitas akun sosmed, semoga kedepan nya tersedia versi android nya min
																</p>
															</div>
														</div>
													</div>
												</div>
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/sigitwardana.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Sigit Wardana</span>
																<p class="client-career">Agen</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	Harga sangat terjangkau dan proses penambahan follower nya juga cepat, ga di ragukan lagi, mantabs!
																</p>
															</div>
														</div>
													</div>
												</div>
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/anisasafa.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Anisa Saffa</span>
																<p class="client-career">Agen</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	Harganya murah, penggunaan yg mudah dan pelayanan yg ramah. Recommen banget pokoknya ^_^
																</p>
															</div>
														</div>
													</div>
												</div>
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/rianaramadhan.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Riana Ramadhan</span>
																<p class="client-career">Member</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	Orderan jasa sosmednya murah banget dan masuknya juga cepet, makasih kak
																</p>
															</div>
														</div>
													</div>
												</div>
												<div class="swiper-slide testimonials-slide">
													<div class="row table-row">
														<div class="col-lg-3 col-left table-cel">
															<div class="client-info text-center">
																<div class="client-pic">
																	<img alt="testimonial" src="images/clients/budiprasetyo.jpg?v<?php echo $versi; ?>" class="center-block">
																</div>
																<span class="client-name">Budi Prasetya</span>
																<p class="client-career">Member</p>
															</div>
														</div>
														<div class="col-lg-9 col-right table-cel">
															<div class="client-review">
																<p>
																	SMM panel terbaik menurut saya, penggunaan mudah dan fiturnya sesuai kebutuhan pekerjaan saya. Belum bisa pindah ke tool lain hehe.. sukses terus bosku!
																</p>
															</div>
														</div>
													</div>
												</div>
											</div>

											<!--Add Arrows-->
											<div class="testimonials-slider-button-prev swiper-button-prev"></div>
											<div class="testimonials-slider-button-next swiper-button-next"></div>
										</div>
									</div>
								</div>
							</div>
							<center>
								<a href="/halaman/produk-dan-layanan"> <img src="/assets/images/halaman/mitra-dan-jaringan.png" class="img-responsive" title="<?php echo $data['short_title'];?>" alt="<?php echo $data['short_title'];?>">
								</a>
							</center>
						</div>
					</div>
				</section>

				<!--FAQ-->
				<section class="faq" id="faqs">
					<div class="container">
						<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
							<h2>
								<i class="fa fa-question-circle"></i> Pertanyaan Umum
							</h2>
							<span><span></span></span>
						</div>
						<div class="row">
							<div class="panel-group questions-container" id="accordion" role="tablist" aria-multiselectable="true">
								<div class="col-md-6 align-left">
									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingOne">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
													<span>Apa Itu <?php echo $data['short_title']; ?>?</span>
												</a>
											</span>
										</div>
										<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne" aria-expanded="true">
											<div class="panel-body">
												<p>
													<?php echo $data['short_title']; ?> adalah penyedia <b>layanan optimasi</b> &amp; otomatisasi digital <b>berteknologi AI</b>, berkualitas, cepat &amp; aman. Kami berkomitmen mempopulerkan bisnis Anda di internet. Layanan unggulan kami dapat melakukan Optimasi Sosial Media &amp; Toko Online, penyedia Produk Virtual Terkoneksi PPOB.
												</p>
											</div>
										</div>
									</div>

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingTwo">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
													<span>Apakah <?php echo $data['short_title']; ?> Gratis?</span>
												</a>
											</span>
										</div>
										<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Akses layanan gratis untuk semua pengguna dengan sistem Penambahan Saldo &amp; giveaway. Lama waktu layanan gratis mengikuti aturan yang ditetapkan, kami memberikan layanan gratis apabila ada event tertentu, fitur baru, atau perayaan momen spesial.
												</p>
											</div>
										</div>
									</div>

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingThree">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
													<span>Bagaimana Cara Order di <?php echo $data['short_title']; ?>?</span>
												</a>
											</span>
										</div>
										<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Klik <b>Dasboard</b> atau menu <b>Order Baru</b>, pilih <b>Kategori</b>, pilih <b>Produk/Layanan</b>, masukkan jumlah orderan, lalu klik <b>Order</b>. Setelah itu akan muncul status order, Anda juga bisa melihat informasi pemesanan pada menu <b>Riwayat Order</b>.
												</p>
											</div>
										</div>
									</div>

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingFour">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
													<span>Bagaimana Jika Status Partial/Error?</span>
												</a>
											</span>
										</div>
										<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Dengan <?php echo $total_layanan; ?>+ layanan, pada kondisi tertentu respon server kami tidak dapat memproses orderan hingga sukses. Ini karena relasi server tersebut maintenance. Jika <a title="Penjelasan Status Order <?php echo $data['short_title']; ?>" alt="Penjelasan Status Order <?php echo $data['short_title']; ?>" href="/halaman/status-order"><b> Status Order</b></a> terjadi Partial/Error, sistem akan otomatis mengembalikan dana/refund detik itu juga.
												</p>
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-6 align-right">

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingFive">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
													<span>Apa Kelebihan <?php echo $data['short_title']; ?>?</span>
												</a>
											</span>
										</div>
										<div id="collapseFive" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFive" aria-expanded="true">
											<div class="panel-body">
												<p>
													Dibanding jasa serupa lainnya, <?php echo $data['short_title']; ?> memberikan harga termurah, berteknologi bot AI tercepat, serta keamanan transaksi perbankan &amp; PPOB yang terjamin. <?php echo $data['short_title']; ?> juga menyediakan edukasi bisnis dan panduan penggunaan sistem untuk Member, Agen, dan Reseller di <a title="Website Portal Bisnis" alt="Website Portal Bisnis" href="https://blog.kincaimedia.net" target="_blank" rel="dofollow"><b>Website Portal Bisnis</b></a>.
												</p>
											</div>
										</div>
									</div>

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingSix">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="true" aria-controls="collapseSix">
													<span>Bagaimana Cara Deposit di <?php echo $data['short_title']; ?>?</span>
												</a>
											</span>
										</div>
										<div id="collapseSix" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingSix" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Klik menu <b>Isi Saldo</b>, pilih metode deposit, pilih sistem konfirmasi (Otomatis/Manual), isi nominal deposit, klik submit. Lakukan pembayaran. Setelah transfer selesai klik konfirmasi di menu <b>Tagihan</b>. Metode "Otomatis" akan dikonfirmasi detik itu juga!
												</p>
											</div>
										</div>
									</div>
									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingSeven">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
													<span>Bagaimana Kinerja Server <?php echo $data['short_title']; ?>?</span>
												</a>
											</span>
										</div>
										<div id="collapseSeven" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingSeven" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Order sukses tercepat mulai 1 sampai 5 menit (jika sedang tidak melakukan sinkronisasi data), kami akan terus meningkatkan kinerja server. Jika orderan pending, mohon menunggu paling lama 1x24 jam.
												</p>
											</div>
										</div>
									</div>

									<div class="panel panel-default wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.25s; animation-name: fadeInUp;">
										<div class="panel-heading" role="tab" id="headingEight">
											<span class="panel-title">
												<a class="gradient-bg" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="true" aria-controls="collapseEight">
													<span>Bagaimana Jika Order Tidak Ada Status?</span>
												</a>
											</span>
										</div>
										<div id="collapseEight" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingEight" aria-expanded="true" style="">
											<div class="panel-body">
												<p>
													Jika lebih dari 1x24 jam orderan stuck, kami bisa membantu memproses secara manual. Ini biasanya karena server relasi kami sedang melakukan sinkronisasi database. Jika lebih dari 2x24 jam orderan tetap stuck, segera mengirim pesan pada halaman <b>Tiket Bantuan</b>.
												</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<!--Teknologi-->
				<section class="mini-feature__style-2 statistics section-bg-img">
					<div class="app-overlay">
						<div class="container text-center">
							<div class="section-title style-gradient white-color wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
								<h2>
									<i class="fa fa-server"></i> Dukungan Teknologi
								</h2>
								<span><span></span></span>
							</div>
							<div class="row white-color">
								<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="AI Technology <?php echo $data['short_title']; ?>" src="images/flat-icons/kmpanel.webp">
											<img alt="AI Technology <?php echo $data['short_title']; ?>" src="images/flat-icons/kmpanel.webp">
										</div>
										<div class="data-box">
											<h3>AI Technology</h3>
											<span>
												Artificial Intelligence
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Intel <?php echo $data['short_title']; ?>" src="images/flat-icons/intel.webp">
											<img alt="Intel <?php echo $data['short_title']; ?>" src="images/flat-icons/intel.webp">
										</div>
										<div class="data-box">
											<h3>Intel</h3>
											<span>
												Intel Corporation
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Domainesia <?php echo $data['short_title']; ?>" src="images/flat-icons/domainesia.webp">
											<img alt="Domainesia <?php echo $data['short_title']; ?>" src="images/flat-icons/domainesia.webp">
										</div>
										<div class="data-box">
											<h3>Domainesia</h3>
											<span>
												Cloud Hosting
											</span>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Cloudlinux <?php echo $data['short_title']; ?>" src="images/flat-icons/cloudlinux.webp">
											<img alt="Cloudlinux <?php echo $data['short_title']; ?>" src="images/flat-icons/cloudlinux.webp">
										</div>
										<div class="data-box">
											<h3>Cloudlinux</h3>
											<span>
												Hosting & Data Center
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Cloudflare <?php echo $data['short_title']; ?>" src="images/flat-icons/cloudflare.webp">
											<img alt="Cloudflare <?php echo $data['short_title']; ?>" src="images/flat-icons/cloudflare.webp">
										</div>
										<div class="data-box">
											<h3>Cloudflare</h3>
											<span>
												Content Delivery Network
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Cpanel <?php echo $data['short_title']; ?>" src="images/flat-icons/cpanel.webp">
											<img alt="Cpanel <?php echo $data['short_title']; ?>" src="images/flat-icons/cpanel.webp">
										</div>
										<div class="data-box">
											<h3>Cpanel</h3>
											<span>
												Host Control Panel
											</span>
										</div>
									</div>
								</div>

								<div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="PHP <?php echo $data['short_title']; ?>" src="images/flat-icons/php.webp">
											<img alt="PHP <?php echo $data['short_title']; ?>" src="images/flat-icons/php.webp">
										</div>
										<div class="data-box">
											<h3>PHP</h3>
											<span>
												Hypertext Preprocessor
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="MySQL <?php echo $data['short_title']; ?>" src="images/flat-icons/mysql.webp">
											<img alt="MySQL <?php echo $data['short_title']; ?>" src="images/flat-icons/mysql.webp">
										</div>
										<div class="data-box">
											<h3>MySQL</h3>
											<span>
												Database Management System
											</span>
										</div>
									</div>
									<div class="mini-feature-box">
										<div class="icon-box">
											<img alt="Let's Encrypt <?php echo $data['short_title']; ?>" src="images/flat-icons/letsencrypt.webp">
											<img alt="Let's Encrypt smm panel" src="images/flat-icons/letsencrypt.webp">
										</div>
										<div class="data-box">
											<h3>Let's Encrypt</h3>
											<span>
												Transport Layer Security
											</span>
										</div>
									</div>
								</div>
							</div>

							<center>
								<a href="/halaman/produk-dan-layanan"> <img src="/assets/images/halaman/tentang-kami.png" class="img-responsive" title="<?php echo $data['short_title'];?>" alt="<?php echo $data['short_title'];?>">
								</a>
							</center>

						</div>
					</div>
				</section>

				<!--Pembayaran-->
				<section class="mini-feature__style-2">
					<div class="container text-center">
						<div class="section-title style-gradient wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
							<h2>
								<i class="fa fa-credit-card"></i> Metode Pembayaran
							</h2>
							<span><span></span></span>
						</div>
						<div class="row" style="font-weight: bold;">
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="BNI" src="/assets/images/pembayaran/kincaimedia-deposit-bni.png">
										<img alt="BNI" src="/assets/images/pembayaran/kincaimedia-deposit-bni.png">
									</div>
									<div class="data-box">
										<h3>BNI</h3>
										<span>
											PT. Bank Negara Indonesia (Persero), Tbk.
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="BRI" src="/assets/images/pembayaran/kincaimedia-deposit-bri.png">
										<img alt="BRI" src="/assets/images/pembayaran/kincaimedia-deposit-bri.png">
									</div>
									<div class="data-box">
										<h3>BRI</h3>
										<span>
											PT. Bank Rakyat Indonesia (Persero), Tbk.
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="BCA" src="/assets/images/pembayaran/kincaimedia-deposit-bca.png">
										<img alt="BCA" src="/assets/images/pembayaran/kincaimedia-deposit-bca.png">
									</div>
									<div class="data-box">
										<h3>BCA</h3>
										<span>
											PT. Bank Central Asia, Tbk.
										</span>
									</div>
								</div>
							</div>
							<div style="clear:both"/>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="GOPAY" src="/assets/images/pembayaran/kincaimedia-deposit-gopay.png">
										<img alt="GOPAY" src="/assets/images/pembayaran/kincaimedia-deposit-gopay.png">
									</div>
									<div class="data-box">
										<h3>GOPAY</h3>
										<span>
											PT. Dompet Anak Bangsa
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="OVO" src="/assets/images/pembayaran/kincaimedia-deposit-ovo.png">
										<img alt="OVO" src="/assets/images/pembayaran/kincaimedia-deposit-ovo.png">
									</div>
									<div class="data-box">
										<h3>OVO</h3>
										<span>
											PT. Visionet Internasional
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="DANA" src="/assets/images/pembayaran/kincaimedia-deposit-dana.png">
										<img alt="DANA" src="/assets/images/pembayaran/kincaimedia-deposit-dana.png">
									</div>
									<div class="data-box">
										<h3>DANA</h3>
										<span>
											PT. Espay Debit Indonesia Koe
										</span>
									</div>
								</div>
							</div>
							<div style="clear:both"/>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="TELKOMSEL" src="/assets/images/pembayaran/kincaimedia-deposit-telkomsel.png">
										<img alt="TELKOMSEL" src="/assets/images/pembayaran/kincaimedia-deposit-telkomsel.png">
									</div>
									<div class="data-box">
										<h3>TELKOMSEL</h3>
										<span>
											PT. Telekomunikasi Selular.
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="XL AXIATA" src="/assets/images/pembayaran/kincaimedia-deposit-xl.png">
										<img alt="XL AXIATA" src="/assets/images/pembayaran/kincaimedia-deposit-xl.png">
									</div>
									<div class="data-box">
										<h3>XL AXIATA</h3>
										<span>
											PT. XL Axiata, Tbk.
										</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-6 wow fadeInUp">
								<div class="mini-feature-box">
									<div class="icon-box">
										<img alt="AXIS" src="/assets/images/pembayaran/kincaimedia-deposit-axis.png">
										<img alt="AXIS" src="/assets/images/pembayaran/kincaimedia-deposit-axis.png">
									</div>
									<div class="data-box">
										<h3>AXIS</h3>
										<span>
											PT. XL Axiata, Tbk.
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

				<!--Pelanggan-->
				<section class="contact contact__style-2 section-bg-img" id="kontak">
					<div class="app-overlay">
						<div class="container text-center">
							<div class="section-title style-gradient white-color wow fadeInUp" data-wow-duration="1s" data-wow-delay="0s">
								<h2>
									<i class="fa fa-comments"></i> Dukungan Pelanggan
								</h2>
								<span><span></span></span>
							</div>
							<div class="contact-form wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
								<div class="row">
									<div class="col-md-0 col-lg-push-8 col-md-push-8">
										<div class="contact-info">
											<div class="info-box">
												<div class="icon-box">
													<img alt="Dukungan Pelanggan <?php echo $data['short_title']; ?>" src="images/flat-icons/support-man.png">
													<img alt="Dukungan Pelanggan <?php echo $data['short_title']; ?>" src="images/flat-icons/support-woman.png">
												</div>
												<div class="data-box">
													<h3>Hubungi Kami</h3>
													<span>
														Jangan ragu menghubungi kami melalui whatsapp <?php echo $data['whatsapp']; ?>, halaman kontak, atau via email <?php echo $data['email']; ?>.
													</span>
												</div>
											</div>
											<div class="info-box">
												<a href="<?php echo $data['url_whatsapp']; ?>" target="_blank"  title="WhatsApp <?php echo $data['short_title'];?>" alt="WhatsApp <?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient"><span><i class="fa fa-whatsapp"></i></span></a>
												<a href="/halaman/hubungi-kami" title="Kontak <?php echo $data['short_title'];?>" alt="Kontak <?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient"><span><i class="fa fa-comments"></i></span></a>
												<a href="<?php echo $data['url_email']; ?>" title="Email <?php echo $data['short_title'];?>" alt="Email <?php echo $data['short_title'];?>" class="appsLand-btn appsLand-btn-gradient"><span><i class="fa fa-envelope"></i></span></a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>

			</main>
			<!--Main-->

			<!--Footer-->
			<footer class="apps-footer">
				<div class="footer-top">
					<div class="container">
						<ul class="list-inline list-unstyled footer-social-links">
							<li>
								<img src="/assets/images/kincaimedia/webkmpanelwhite.png?v<?php echo $versi; ?>" width="280px" class="img-responsive" title="Website <?php echo $data['short_title']; ?>" alt="Website <?php echo $data['short_title']; ?>">
							</li>
							<br/>
							<li><a href="<?php echo $data['url_whatsapp']; ?>" target="_blank" alt="Database Youtube SMM Panel Indoensia" title="Whatsapp Panel dan Server Pulsa H2H"><i class="fa fa-whatsapp"></i></a></li>
							<li><a href="<?php echo $data['url_email']; ?>" target="_blank" alt="Database Instagram SMM Panel Indoensia" title="Email Panel dan Server Pulsa H2H"><i class="fa fa-envelope"></i></a></li>
							<li><a href="<?php echo $data['url_youtube']; ?>" target="_blank" alt="Database Youtube SMM Panel Indoensia" title="Youtube Panel dan Server Pulsa H2H"><i class="fa fa-youtube"></i></a></li>
							<li><a href="<?php echo $data['url_facebook']; ?>" target="_blank" alt="Database Facebook SMM Panel Indoensia" title="Facebook Panel dan Server Pulsa H2H"><i class="fa fa-facebook"></i></a></li>
							<li><a href="<?php echo $data['url_instagram']; ?>" target="_blank" alt="Database Instagram SMM Panel Indoensia" title="Instagram Panel dan Server Pulsa H2H"><i class="fa fa-instagram"></i></a></li>
							<li><a href="<?php echo $data['url_twitter']; ?>" target="_blank" alt="Database Instagram SMM Panel Indoensia" title="Twitter Panel dan Server Pulsa H2H"><i class="fa fa-twitter"></i></a></li>
							<li><a href="https://mediabisnis.co.id" target="_blank" alt="Database Instagram SMM Panel Indoensia" title="Blog Panel dan Server Pulsa H2H"><i class="fa fa-rss"></i></a></li>
						</ul>
					</div>
				</div>

				<div class="footer-bottom">
					<div class="container" style="text-align: center; text-transform: capitalize;">
						<div class="col-md-6">
							Copyright &copy;<?php echo date("Y"); ?> <?php echo $data['short_title']; ?>.
						</div>
						<div class="col-md-6">
							<a href="<?php echo $config['web']['url'];?>halaman/tentang-kami" alt="Tentang Kami" title="Tentang Kami"> About </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/dukungan-teknologi" alt="Dukungan Teknologi" title="Dukungan Teknologi"> Techno </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/produk-dan-layanan" alt="Produk dan Jasa" title="Produk dan Jasa"> Services </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/dukungan-pembayaran" alt="Dukungan Pembayaran" title="Dukungan Pembayaran"> Payments </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/platform-aplikasi" alt="Platform Aplikasi" title="Platform Aplikasi"> Platforms </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/mitra-dan-jaringan" alt="Mitra dan Jaringan" title="Mitra dan Jaringan"> Partners </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/ketentuan-layanan" alt="Ketentuan Layanan" title="Ketentuan Layanan"> Privacy </a>
							•
							<a href="<?php echo $config['web']['url'];?>halaman/pertanyaan-umum" alt="Pertanyaan Umum" title="Pertanyaan Umum"> FAQs </a>
						</div>
					</div>
				</div>
			</footer>

			<div class="loading">
				<div class="spinner">
					<div class="double-bounce1"></div>
					<div class="double-bounce2"></div>
				</div>
			</div>

			<!--Scroll-->
			<div class="scrollToTop appsLand-btn appsLand-btn-gradient"><span><i class="fa fa-angle-up"></i></span></div>

			<!--start the script-->
			<script src="js/jquery-2.2.4.min.js"></script>
			<script src="js/bootstrap.min.js"></script>
			<script src="js/swiper.jquery.min.js"></script>
			<script src="js/wow.min.js"></script>
			<script src="js/jquery.countTo.min.js"></script>
			<script src="js/lity.min.js"></script>
			<script src="js/plugins.js"></script>
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.ajaxchimp.langs.min.js"></script>
			<script src="js/ajax.js"></script>

			<?php
			include_once "../lib/SEOSecretIDN-schema-all.php";
			include_once "../lib/SEOSecretIDN-javascript-home.php";
			?>

		</body>
		
	</html>

<?php } ?>