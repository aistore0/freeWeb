<?php
session_start();
require '../config.php';
require '../lib/session_login_admin.php';                    
require '../lib/header_admin.php';

// Panggil API ID, API KEY, SECRET KEY dengan CODE Provider

$cek_mail = $conn->query("SELECT * FROM setting_web");
$data_mail = mysqli_fetch_assoc($cek_mail);

$cekdpedia = $conn->query("SELECT * FROM provider WHERE code = 'ARIETOPUP'");
$datadpedia = mysqli_fetch_assoc($cekdpedia);
$actionarie = 'profile';

$cekwa = $conn->query("SELECT * FROM provider WHERE code = 'ARIEGATEWAY'");
$datawa = mysqli_fetch_assoc($cekwa);

?> 

<!-- Page-Title -->
<div class="row">
    <div class="col-md-12">
        <br /><h2 class="text-center">Manajemen Data Akun Provider Server Pusat Database</h2><br/>
    </div>
</div>
<!-- End-Page-Title -->

<div class="row">
    <div class="col-md-4">
        <div class="card">    
            <div class="card-body table-responsive">                            
                <h4 class="m-t-0 header-title text-center">INFORMASI AKUN PUSAT</h4><hr>
                <!--ARIE PULSA-->
            <?php
            $postdata = "api_key=".$datadpedia['api_key']."&action=".$actionarie."";
            $url = 'https://ariepulsa.id/api/profile';
                
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($curl, CURLOPT_TIMEOUT,0);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); // tambahan curl ipv4
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, POST);
            curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	    	$response = curl_exec($curl);
            curl_close($curl);
			/*
			echo $response;
			*/
            $json_result = json_decode($response, true);
            ?>
                <h5 class="btn btn-primary btn-block">ARIETOPUP (https://ariepulsa.id)</h5>
                <div class="text-dark">
                    Username: <?php echo $json_result['data']['username']; ?><br />
                    Poin: <?php echo number_format($json_result['data']['poin'],0,',','.'); ?><br />
                    <b>Saldo: Rp. <?php echo number_format($json_result['data']['sisa_saldo'],0,',','.'); ?></b>
                </div>

                <!--WAGATEWAY-->
                <?php 
                $postdata = "device=".$datawa['api_id']."&api_key=".$datawa['api_key']."";
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, "https://ariegateway.my.id/generate-qr");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                $chresult = curl_exec($ch);
                //echo $chresult;
                curl_close($ch);
                $json_result = json_decode($chresult, true);
                ?>
                <h5 class="btn btn-primary btn-block">ARIEGATEWAY (https://ARIEGATEWAY.my.id)</h5>
                <div class="text-dark">
                    <b>Status: <?php echo $json_result['msg']; ?></b>
                </div>
                

            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card table-responsive">
            <div class="card-body">
                <h4 class="m-t-0 header-title text-center">UPDATE LAYANAN & KATEGORI</h4><hr>
                <center>
                    <b> ARIETOPUP PPOB</b>
                    <div class="center">
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-category-pulsa-ppob" target="_blank">Upd. Kategori</a>
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-layanan-pulsa-ppob" target="_blank">Upd. Layanan</a>
                        <a class="btn btn-success waves-effect w-md waves-light" href="../cronsjob/status_pulsa" target="_blank">Status Order</a>
                    </div> <br/>
                     <b> ARIETOPUP DIGITAL</b>
                    <div class="center">
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-category-digital" target="_blank">Upd. Kategori</a>
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-layanan-digital" target="_blank">Upd. Layanan</a>
                        <a class="btn btn-success waves-effect w-md waves-light" href="../cronsjob/status_digital" target="_blank">Status Order</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM 1</b>
                    <div class="center">
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-layanan-sosmed" target="_blank">Update SMM</a>
                        <a class="btn btn-success waves-effect w-md waves-light" href="../cronsjob/status_sosmed" target="_blank">Status Order</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM 2</b>
                    <div class="center">
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-layanan-sosmed-2" target="_blank">Update SMM</a>
                        <a class="btn btn-success waves-effect w-md waves-light" href="../cronsjob/status_sosmed_2" target="_blank">Status Order</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM 3</b>
                    <div class="center">
                        <a class="btn btn-info waves-effect w-md waves-light" href="../get/upd-all-layanan-sosmed-3" target="_blank">Update SMM</a>
                        <a class="btn btn-success waves-effect w-md waves-light" href="../cronsjob/status_sosmed_3" target="_blank">Status Order</a>
                    </div> 
                </center>                 
            </div>                               
        </div>                        
    </div>

    <div class="col-md-4">
        <div class="card table-responsive">
            <div class="card-body">
                <h4 class="m-t-0 header-title text-center">HAPUS LAYANAN & KATEGORI</h4><hr>	
                <center>
                    <b> ARIETOPUP PPOB</b>
                    <div class="center">
                  <!--       <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-category" target="_blank">Del. Kategori</a> -->
                        <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-layanan-pulsa-ppob" target="_blank">Del. Layanan</a>
                    </div> <br/>
                    <b> ARIETOPUP DIGITAL</b>
                    <div class="center">
                        <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-layanan-digital" target="_blank">Del. Digital</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM</b>
                    <div class="center">
                        <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-layanan-sosmed" target="_blank">Del. SMM</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM 2</b>
                    <div class="center">
                        <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-layanan-sosmed-2" target="_blank">Del. SMM 2</a>
                    </div> <br/>
                    <b> ARIETOPUP SMM 3</b>
                    <div class="center">
                        <a class="btn btn-warning waves-effect w-md waves-light" href="../get/del-all-layanan-sosmed-3" target="_blank">Del. SMM 3</a>
                    </div> <br/>
                    <b> ALL PROVIDER</b>
                    <div class="center">
                        <a class="btn btn-danger waves-effect w-md waves-light" href="../get/del-all-layanan" target="_blank">Delete All</a>
                    </div>
                </center>
            </div>

        </div>                        
    </div>

    <?php 
    require '../lib/footer_admin.php';
    ?>